-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: acat1
-- ------------------------------------------------------
-- Server version	5.1.73-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `value`
--

DROP TABLE IF EXISTS `value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `value` (
  `valueid` int(11) NOT NULL AUTO_INCREMENT,
  `attributeid` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `lastModified` datetime DEFAULT NULL,
  `valuename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`valueid`),
  KEY `FK4E9A151897DECE2` (`attributeid`),
  CONSTRAINT `FK4E9A151897DECE2` FOREIGN KEY (`attributeid`) REFERENCES `attribute` (`attributeid`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `value`
--

LOCK TABLES `value` WRITE;
/*!40000 ALTER TABLE `value` DISABLE KEYS */;
INSERT INTO `value` (`valueid`, `attributeid`, `created`, `lastModified`, `valuename`) VALUES (1,1,NULL,NULL,'Enterprise Resource Management'),(2,1,NULL,NULL,'Blog'),(3,1,NULL,NULL,'BI Tool'),(4,1,NULL,NULL,'Collaboration Tool'),(5,1,NULL,NULL,'Community Forums'),(6,1,NULL,NULL,'CRM'),(7,1,NULL,NULL,'E-Commerce'),(8,1,NULL,NULL,'Engineering'),(9,1,NULL,NULL,'Enterprise Content Management'),(10,1,NULL,NULL,'Financial'),(11,1,NULL,NULL,'Gaming'),(12,1,NULL,NULL,'Media Streaming'),(14,1,NULL,NULL,'Office Suites'),(15,1,NULL,NULL,'Operations and Manufacturing'),(16,1,NULL,NULL,'Other Business Application'),(17,1,NULL,NULL,'Payroll'),(18,1,NULL,NULL,'Project and Portfolio Management'),(19,1,NULL,NULL,'Sales/Marketing Tools'),(20,1,NULL,NULL,'Simulation/Analytics'),(21,1,NULL,NULL,'Social Networking'),(22,1,NULL,NULL,'Supply Chain Management'),(23,1,NULL,NULL,'Unified Communication'),(24,2,NULL,NULL,'New Application'),(25,2,NULL,NULL,'Supported/Managed'),(26,2,NULL,NULL,'Approaching End of Life'),(27,2,NULL,NULL,'End of Life'),(28,3,NULL,NULL,'Business'),(29,3,NULL,NULL,'Technology'),(30,3,NULL,NULL,'NA'),(31,4,NULL,NULL,'Microsoft - .NET'),(32,4,NULL,NULL,'Microsoft - Legacy'),(33,4,NULL,NULL,'Java/J2EE'),(34,4,NULL,NULL,'OpenSource(PHP,Ruby,Python,etc)'),(35,4,NULL,NULL,'Hybrid(MS+Java+Others)'),(37,4,NULL,NULL,'SharePoint'),(38,4,NULL,NULL,'Oracle Suite'),(39,4,NULL,NULL,'SAP Application'),(40,4,NULL,NULL,'SAP Core(ECC)'),(41,4,NULL,NULL,'SAP Core(HCM)'),(42,4,NULL,NULL,'SAP Core(PLM)'),(43,4,NULL,NULL,'SAP Core(SCM)'),(44,4,NULL,NULL,'SAP Core(SRM)'),(45,4,NULL,NULL,'Others'),(46,5,NULL,NULL,'MSSQL'),(47,5,NULL,NULL,'Oracle'),(48,5,NULL,NULL,'MySQL'),(49,5,NULL,NULL,'PostgresSQL'),(50,5,NULL,NULL,'HANA'),(51,5,NULL,NULL,'Others'),(52,6,NULL,NULL,'Desktop/Thick Client'),(53,6,NULL,NULL,'Web'),(54,7,NULL,NULL,'Cannot be placed outside enterprise firewall'),(55,7,NULL,NULL,'Can be placed in approved public datacenters'),(56,8,NULL,NULL,'Little or No variations'),(57,8,NULL,NULL,'Predictable fluctuating by time and/or volume'),(58,8,NULL,NULL,'Unpredictable and fluctuating'),(60,9,NULL,NULL,'Available'),(61,9,NULL,NULL,'Performance'),(62,9,NULL,NULL,'Both'),(63,10,NULL,NULL,'Revenue Generating'),(64,10,NULL,NULL,'Supports Revenue'),(65,10,NULL,NULL,'Supports Risk Limiting Activities'),(66,10,NULL,NULL,'Internal Support'),(67,11,NULL,NULL,'Mission Critical'),(68,11,NULL,NULL,'Business Critical'),(69,11,NULL,NULL,'Business Important'),(70,11,NULL,NULL,'Productivity Important'),(71,11,NULL,NULL,'Non-Critical'),(72,12,NULL,NULL,'Severe Financial Loss and/or Regulatory Compliance Impacted'),(73,12,NULL,NULL,'Some Financial Loss and/or Large Productivity Loss'),(74,12,NULL,NULL,'Some Productivity Loss'),(75,13,NULL,NULL,'Less than 1,000'),(76,13,NULL,NULL,'1,000 to 10,000'),(77,13,NULL,NULL,'10,000 to 100,000'),(78,13,NULL,NULL,'100,000 to 1 Million'),(79,13,NULL,NULL,'Over 1 Million'),(80,14,NULL,NULL,'Local'),(81,14,NULL,NULL,'Regional'),(82,14,NULL,NULL,'National'),(83,14,NULL,NULL,'International'),(84,15,NULL,NULL,'Internal'),(85,15,NULL,NULL,'Client Facing'),(86,16,NULL,NULL,'Horizontal Scaling for all tiers'),(87,16,NULL,NULL,'Vertical Scaling for all tiers'),(88,16,NULL,NULL,'Mixed'),(89,17,NULL,NULL,'Monolithic Components'),(90,17,NULL,NULL,'Loosely coupled with well-defined interfaces'),(91,17,NULL,NULL,'Service Oriented Architecture'),(92,18,NULL,NULL,'Linux'),(93,18,NULL,NULL,'Unix'),(94,18,NULL,NULL,'Windows'),(95,18,NULL,NULL,'Mainframe/Mid-range'),(96,18,NULL,NULL,'Other'),(97,19,NULL,NULL,'32 Bit RISC'),(98,19,NULL,NULL,'32 Bit Vendor Specific'),(99,19,NULL,NULL,'64 Bit Vendor Specific'),(100,19,NULL,NULL,'32 Bit x86 Based'),(101,19,NULL,NULL,'64 Bit x86 Based'),(102,20,NULL,NULL,'Hardware Dependent'),(103,20,NULL,NULL,'Operating System Dependent'),(104,20,NULL,NULL,'Operating System Version Dependent'),(105,20,NULL,NULL,'Operating Environment Dependent'),(106,20,NULL,NULL,'Operating Environment Version Dependent'),(107,21,NULL,NULL,'Low-No latency sensitive processing'),(108,21,NULL,NULL,'Medium-Online financial transactions'),(109,21,NULL,NULL,'High-Extreme low latency or real time sensitive'),(110,22,NULL,NULL,'Low-Low or few periods of increased I/O rate'),(111,22,NULL,NULL,'Medium-Intermittently fluctuating'),(112,22,NULL,NULL,'High-High I/O rates'),(113,23,NULL,NULL,'Internal'),(114,23,NULL,NULL,'External/Vendor'),(115,23,NULL,NULL,'COTS'),(116,24,NULL,NULL,'Yes'),(117,24,NULL,NULL,'No'),(118,4,NULL,NULL,'Microsoft Exchange');
/*!40000 ALTER TABLE `value` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-09 12:00:45
