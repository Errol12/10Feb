-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: acat1
-- ------------------------------------------------------
-- Server version	5.1.73-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `disposition`
--

DROP TABLE IF EXISTS `disposition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disposition` (
  `dispositionid` int(11) NOT NULL AUTO_INCREMENT,
  `applicationid` int(11) NOT NULL,
  `clientid` int(11) NOT NULL,
  `cloud_stability` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `disposition` varchar(255) DEFAULT NULL,
  `lastModified` datetime DEFAULT NULL,
  `projectid` int(11) NOT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `tool` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`dispositionid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disposition`
--

LOCK TABLES `disposition` WRITE;
/*!40000 ALTER TABLE `disposition` DISABLE KEYS */;
INSERT INTO `disposition` VALUES (1,4,4,' Public','2017-01-12 15:40:32',' Develop ','2017-01-12 15:40:32',1,'COTS ',' Atos Cloud Foundry '),(2,5,1,' NA','2017-01-12 15:40:37',' Retain ','2017-01-12 15:40:37',2,'SAP Application ',' NA '),(3,6,1,' Private','2017-01-12 15:40:37',' Develop ','2017-01-12 15:40:37',2,'SAP Core(HCM) ',' Atos Cloud Foundry '),(4,9,1,' NA','2017-01-12 15:40:37',' Retain ','2017-01-12 15:40:37',2,'SAP Core(PLM) ',' NA '),(5,8,1,' Private','2017-01-12 15:40:38',' Develop ','2017-01-12 15:40:38',2,'SAP Core(PLM) ',' Atos Cloud Foundry '),(6,7,1,' Private','2017-01-12 15:40:38',' Develop ','2017-01-12 15:40:38',2,'SAP Core(PLM) ',' Atos Cloud Foundry '),(7,10,1,' Private','2017-01-12 15:40:38',' Develop ','2017-01-12 15:40:38',2,'Java/J2EE ',' Atos Cloud Foundry '),(8,12,1,' Private','2017-01-12 15:40:38',' Develop ','2017-01-12 15:40:38',2,'SharePoint ',' Atos Cloud Foundry '),(9,13,1,' Public','2017-01-12 15:40:38',' Modernise ','2017-01-12 15:40:38',2,'Java/J2EE ',' Atos Cloud Foundry '),(10,14,1,' Public','2017-01-12 15:40:38',' Modernise ','2017-01-12 15:40:38',2,'Microsoft - Legacy ',' Apprenda '),(11,5,1,' NA','2017-01-12 15:40:43',' Retain ','2017-01-12 15:40:43',3,'SAP Application ',' NA '),(12,6,1,' Public','2017-01-12 15:40:43',' Develop ','2017-01-12 15:40:43',3,'SAP Core(HCM) ',' Atos Cloud Foundry '),(13,9,1,' NA','2017-01-12 15:40:43',' Retain ','2017-01-12 15:40:43',3,'SAP Core(PLM) ',' NA '),(14,8,1,' Public','2017-01-12 15:40:43',' Develop ','2017-01-12 15:40:43',3,'SAP Core(PLM) ',' Atos Cloud Foundry '),(15,7,1,' Public','2017-01-12 15:40:43',' Develop ','2017-01-12 15:40:43',3,'SAP Core(PLM) ',' Atos Cloud Foundry '),(16,10,1,' Public','2017-01-12 15:40:43',' Develop ','2017-01-12 15:40:43',3,'Java/J2EE ',' Atos Cloud Foundry '),(17,12,1,' Public','2017-01-12 15:40:43',' Develop ','2017-01-12 15:40:43',3,'SharePoint ',' Atos Cloud Foundry '),(18,13,1,' Public','2017-01-12 15:40:43',' Modernise ','2017-01-12 15:40:43',3,'Java/J2EE ',' Atos Cloud Foundry '),(19,14,1,' Public','2017-01-12 15:40:43',' Modernise ','2017-01-12 15:40:43',3,'Microsoft - Legacy ',' Apprenda '),(20,5,1,' NA','2017-01-12 15:40:46',' Retain ','2017-01-12 15:40:46',4,'SAP Application ',' NA '),(21,6,1,' Private','2017-01-12 15:40:46',' Develop ','2017-01-12 15:40:46',4,'SAP Core(HCM) ',' Atos Cloud Foundry '),(22,9,1,' NA','2017-01-12 15:40:46',' Retain ','2017-01-12 15:40:46',4,'SAP Core(PLM) ',' NA '),(23,8,1,' Private','2017-01-12 15:40:46',' Develop ','2017-01-12 15:40:46',4,'SAP Core(PLM) ',' Atos Cloud Foundry '),(24,7,1,' Private','2017-01-12 15:40:46',' Develop ','2017-01-12 15:40:46',4,'SAP Core(PLM) ',' Atos Cloud Foundry '),(25,10,1,' Private','2017-01-12 15:40:46',' Develop ','2017-01-12 15:40:46',4,'Java/J2EE ',' Atos Cloud Foundry '),(26,12,1,' Private','2017-01-12 15:40:46',' Develop ','2017-01-12 15:40:46',4,'SharePoint ',' Atos Cloud Foundry '),(27,13,1,' Public','2017-01-12 15:40:46',' Modernise ','2017-01-12 15:40:46',4,'Java/J2EE ',' Atos Cloud Foundry '),(28,14,1,' Public','2017-01-12 15:40:46',' Modernise ','2017-01-12 15:40:46',4,'Microsoft - Legacy ',' Apprenda ');
/*!40000 ALTER TABLE `disposition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-12 15:43:55
