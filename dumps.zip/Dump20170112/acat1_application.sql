-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: acat1
-- ------------------------------------------------------
-- Server version	5.1.73-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application`
--

DROP TABLE IF EXISTS `application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application` (
  `applicationid` int(11) NOT NULL AUTO_INCREMENT,
  `aclientid` int(11) NOT NULL,
  `applicationname` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `lastModified` datetime DEFAULT NULL,
  `text` varchar(255) DEFAULT NULL,
  `clientid` int(11) DEFAULT NULL,
  PRIMARY KEY (`applicationid`),
  KEY `aclientid` (`aclientid`),
  KEY `FKC00DAD302806EC2` (`clientid`),
  CONSTRAINT `application_ibfk_1` FOREIGN KEY (`aclientid`) REFERENCES `client` (`clientid`),
  CONSTRAINT `FKC00DAD302806EC2` FOREIGN KEY (`clientid`) REFERENCES `client` (`clientid`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application`
--

LOCK TABLES `application` WRITE;
/*!40000 ALTER TABLE `application` DISABLE KEYS */;
INSERT INTO `application` VALUES (2,2,'TTS',NULL,'This is an TTS Applications.','2017-01-02 17:34:14',NULL,NULL),(3,3,'BMW e1',NULL,'This is a BMW Application.','2017-01-02 17:40:41',NULL,NULL),(4,4,' Cloud',NULL,'This is a cloud Application.','2017-01-03 10:46:58',NULL,NULL),(5,1,'App M',NULL,'This is M Application.','2017-01-09 16:24:59',NULL,NULL),(6,1,'AAC',NULL,'sada','2017-01-10 11:42:32',NULL,NULL),(7,1,'sa',NULL,'faf','2017-01-10 11:42:46',NULL,NULL),(8,1,'af',NULL,'f','2017-01-10 11:42:52',NULL,NULL),(9,1,'ghjgh',NULL,'fgjj','2017-01-10 11:42:57',NULL,NULL),(10,1,'demodash',NULL,'asfa','2017-01-12 10:56:11',NULL,NULL),(11,1,'Simran',NULL,'Kahlon','2017-01-12 14:52:31',NULL,NULL),(12,1,'Errol',NULL,'Fernandes','2017-01-12 14:52:31',NULL,NULL),(13,1,'Simran 1234',NULL,'Kahlon','2017-01-12 14:54:42',NULL,NULL),(14,1,'5fwerfev',NULL,'Fernandes','2017-01-12 14:54:42',NULL,NULL),(15,1,'ergetg',NULL,'egtrg','2017-01-12 14:54:42',NULL,NULL),(16,1,'tgtrg',NULL,'tgtrr','2017-01-12 14:54:42',NULL,NULL),(17,3,'Simran 1234',NULL,'Kahlon','2017-01-12 15:26:46',NULL,NULL),(18,3,'5fwerfev',NULL,'Fernandes','2017-01-12 15:26:46',NULL,NULL),(19,3,'ergetg',NULL,'egtrg','2017-01-12 15:26:46',NULL,NULL),(20,3,'tgtrg',NULL,'tgtrr','2017-01-12 15:26:46',NULL,NULL),(21,3,'dgsgsg',NULL,'dgsdgdg','2017-01-12 15:26:46',NULL,NULL),(22,3,'axadada',NULL,'ryhrtyrt','2017-01-12 15:26:46',NULL,NULL),(23,3,'asfsadff',NULL,'zxvgdg','2017-01-12 15:26:46',NULL,NULL),(24,3,'aaaaaa',NULL,'qqqqq','2017-01-12 15:26:46',NULL,NULL),(25,3,'rtertert',NULL,'jukouii','2017-01-12 15:26:46',NULL,NULL);
/*!40000 ALTER TABLE `application` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-12 15:43:55
