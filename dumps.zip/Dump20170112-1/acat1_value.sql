-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: acat1
-- ------------------------------------------------------
-- Server version	5.1.73-community

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `value`
--

DROP TABLE IF EXISTS `value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `value` (
  `valueid` int(11) NOT NULL AUTO_INCREMENT,
  `attributeid` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `lastModified` datetime DEFAULT NULL,
  `valuename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`valueid`),
  KEY `attributeid` (`attributeid`),
  CONSTRAINT `value_ibfk_1` FOREIGN KEY (`attributeid`) REFERENCES `attribute` (`attributeid`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `value`
--

LOCK TABLES `value` WRITE;
/*!40000 ALTER TABLE `value` DISABLE KEYS */;
INSERT INTO `value` (`valueid`, `attributeid`, `created`, `lastModified`, `valuename`) VALUES (1,1,NULL,NULL,'Enterprise Resource Management'),(2,1,NULL,NULL,'Blog'),(3,1,NULL,NULL,'BI Tool'),(4,1,NULL,NULL,'Collaboration Tool'),(5,1,NULL,NULL,'Community Forums'),(6,1,NULL,NULL,'CRM'),(7,1,NULL,NULL,'E-Commerce'),(8,1,NULL,NULL,'Engineering'),(9,1,NULL,NULL,'Enterprise Content Management'),(10,1,NULL,NULL,'Financial'),(11,1,NULL,NULL,'Gaming'),(12,1,NULL,NULL,'Media Streaming'),(13,1,NULL,NULL,'Microsoft Exchange'),(14,1,NULL,NULL,'Office Suites'),(15,1,NULL,NULL,'Operations and Manufacturing'),(16,1,NULL,NULL,'Other Business Application'),(17,1,NULL,NULL,'Payroll'),(18,1,NULL,NULL,'Project and Portfolio Management'),(19,1,NULL,NULL,'Sales/Marketing Tools'),(20,1,NULL,NULL,'Simulation/Analytics'),(21,1,NULL,NULL,'Social Networking'),(22,1,NULL,NULL,'Supply Chain Management'),(23,1,NULL,NULL,'Unified Communication'),(24,2,NULL,NULL,'New Application'),(25,2,NULL,NULL,'Supported/Managed'),(26,2,NULL,NULL,'Approaching End of Life'),(27,2,NULL,NULL,'End of Life'),(28,3,NULL,NULL,'Business'),(29,3,NULL,NULL,'Technology'),(30,3,NULL,NULL,'NA'),(31,4,NULL,NULL,'Microsoft - .NET'),(32,4,NULL,NULL,'Microsoft - Legacy'),(33,4,NULL,NULL,'Java/J2EE'),(34,4,NULL,NULL,'OpenSource(PHP,Ruby,Python,etc)'),(35,4,NULL,NULL,'Hybrid(MS+Java+Others)'),(36,4,NULL,NULL,'COTS'),(37,4,NULL,NULL,'SharePoint'),(38,4,NULL,NULL,'Oracle Suite'),(39,4,NULL,NULL,'SAP Application'),(40,4,NULL,NULL,'SAP Core(ECC)'),(41,4,NULL,NULL,'SAP Core(HCM)'),(42,4,NULL,NULL,'SAP Core(PLM)'),(43,4,NULL,NULL,'SAP Core(SCM)'),(44,4,NULL,NULL,'SAP Core(SRM)'),(45,4,NULL,NULL,'Others'),(46,5,NULL,NULL,'MSSQL'),(47,5,NULL,NULL,'Oracle'),(48,5,NULL,NULL,'MySQL'),(49,5,NULL,NULL,'PostgresSQL'),(50,5,NULL,NULL,'HANA'),(51,5,NULL,NULL,'Others'),(52,6,NULL,NULL,'Desktop/Thick Client'),(53,6,NULL,NULL,'Web'),(54,7,NULL,NULL,'Cannot be placed outside enterprise firewall'),(55,7,NULL,NULL,'Can be placed in approved public datacenters'),(56,8,NULL,NULL,'Little or No variations'),(57,8,NULL,NULL,'Predictable fluctuating by time and/or volume'),(58,8,NULL,NULL,'Unpredictable and fluctuating'),(59,1,NULL,NULL,'Microsoft Sharepoint');
/*!40000 ALTER TABLE `value` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-01-12 15:45:05
